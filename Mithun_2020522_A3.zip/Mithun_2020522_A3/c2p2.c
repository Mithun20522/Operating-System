#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <time.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>


int main(){

  int ID = msgget(ftok("temp",24), 0660);
  for (size_t i = 0; i < 10; i++)
  {
    char buffer[5][6];
    bzero(buffer, 30);
    msgrcv(ID, buffer, sizeof(buffer), 0, 0);
    printf("Packets received : \n");
    for (size_t j = 0; j < 5; j++)
    {
      printf("%s, ", buffer[j]);
    }
    printf("\n");
    msgsnd(ID, buffer[4], sizeof buffer[4], 0);
  }
  close(open("temp",O_RDONLY));

  return 0;

}
