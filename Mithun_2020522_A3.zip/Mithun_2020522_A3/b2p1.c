#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

char* GetRandomArrayString(int size) {
	char* str = (char *)malloc(sizeof(char)*(size +1));
	char arr[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

	for(int i= 0; i < size; i++) { str[i]=arr[rand() % (sizeof arr - 1)]; }
	str[size] = '\0';
	return str;
}

int main(){

	srand((unsigned int)(time(NULL)));
  mkfifo("temp",0660);

  for (size_t i = 0; i < 10; i++)
  {
    char buffer[5][6];
    char val[6];
    bzero(buffer, 30);
    bzero(val, 6);
    for (size_t j = 0; j < 5; j++)
    {
      strncpy(buffer[j],GetRandomArrayString(5),6);
    }
    write(open("temp",O_WRONLY),buffer,sizeof(buffer));
    usleep(100);
    read(open("temp",O_RDONLY),val,sizeof(val));
    printf("Returned value of maximum ID is : %s\n",val);
  }
  close(open("temp",O_RDONLY));
  return 0;
}
