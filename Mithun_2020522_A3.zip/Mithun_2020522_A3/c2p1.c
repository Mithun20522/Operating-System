#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

char* getRandomArrayString(int size) {
	char* str = (char *)malloc(sizeof(char)*(size +1));
	char arr[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

	for(int i= 0; i < size; i++) { str[i]=arr[rand() % (sizeof arr - 1)]; }
	str[size] = '\0';
	return str;
}

int main(){

	srand((unsigned int)(time(NULL)));
  int ID = msgget(ftok("temp",24), 0660 | IPC_CREAT);

  for (size_t i = 0; i < 10; i++)
  {
    char buffer[5][6];
    char ret[6];
    bzero(buffer, 30);
    bzero(ret, 6);
    for (size_t j = 0; j < 5; j++) { strncpy(buffer[j],getRandomArrayString(5),6); }
    msgsnd(ID, buffer, sizeof buffer, 0);
    msgrcv(ID, ret, sizeof(ret), 0, 0);
    printf("Returned value of maximum ID is : %s\n",ret);
  }
  close(open("temp",O_RDONLY));
  return 0;
}
