#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <time.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>

int main(){


  for (size_t i = 0; i < 10; i++)
  {
    char buffer[5][6];
    bzero(buffer, 30);
    read(open("temp",O_RDONLY),buffer,sizeof(buffer));
    printf("Packets received : \n");
    for (size_t j = 0; j < 5; j++)
    {
      printf("%s, ", buffer[j]);
    }

    printf("\n");
    usleep(100);
    write(open("temp",O_WRONLY),buffer[4],sizeof(buffer[4]));
  }
  
  close(open("temp",O_RDONLY));

  return 0;

}