#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main(){

  char *IpAddress = "127.0.0.1";
  int PortNO = 1234;

  int client_sock;
  struct sockaddr_in Client_addr;

  client_sock = socket(AF_INET, SOCK_STREAM, 0);
  
  if (client_sock < 0){
    perror("Error Occured in Client Creation........");
    exit(1);
  }

  else{

    memset(&Client_addr, '\0', sizeof(Client_addr));
    Client_addr.sin_family = AF_INET;
    Client_addr.sin_port = PortNO;
    Client_addr.sin_addr.s_addr = inet_addr(IpAddress);

    connect(client_sock, (struct sockaddr*)&Client_addr, sizeof(Client_addr));

    for (size_t i = 0; i < 10; i++)
    {
      char buffer[5][6];
      bzero(buffer, 30);

      recv(client_sock, buffer, sizeof(buffer), 0);
      printf(" Packet Recieved : \n");

      for (size_t j = 0; j < 5; j++)
      {
        printf("%s, ", buffer[j]);
      }
      printf("\n");
      send(client_sock,buffer[4],sizeof(buffer[4]),0);
    }
  }
  
  close(client_sock);

  return 0;

}