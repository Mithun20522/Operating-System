#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>

char* GenerateRandomArrayString(int size) {
	char* str = (char *)malloc(sizeof(char)*(size +1));
	char arr[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

	for(int i= 0; i < size; i++) 
  { 
    str[i]=arr[rand() % (sizeof arr - 1)]; 
  }
	str[size] = '\0';
	return str;
}

int main(){

	srand((unsigned int)(time(NULL)));
  char *IpAddress = "127.0.0.1";
  int PortNO = 1234;

  int serv_sock, client_sock;
  struct sockaddr_in serv_address, client_addr;
  socklen_t SizeOfAdd;

  serv_sock = socket(AF_INET, SOCK_STREAM, 0);

  if (serv_sock < 0){
    perror("Error Occured in server Creation........");
    exit(1);
  }

  else {

    memset(&serv_address, '\0', sizeof(serv_address));
    serv_address.sin_family = AF_INET;
    serv_address.sin_port = PortNO;
    serv_address.sin_addr.s_addr = inet_addr(IpAddress);

    int n = bind(serv_sock, (struct sockaddr*)&serv_address, sizeof(serv_address));

    if (n < 0){
      perror("Error Occured in Binding the server.......");
      exit(1);
    }

    listen(serv_sock, 5);
    SizeOfAdd = sizeof(client_addr);
    client_sock = accept(serv_sock, (struct sockaddr*)&client_addr, &SizeOfAdd);

    for (size_t i = 0; i < 10; i++)
    {
      char buffer[5][6];
      char val[6];
      bzero(buffer, 30);
      bzero(val, 6);
      for (size_t j = 0; j < 5; j++)
      {
        strncpy(buffer[j],GenerateRandomArrayString(5),6);
      }
      send(client_sock, buffer, sizeof(buffer), 0);
      recv(client_sock, val, sizeof(val),0);
      printf("Returned value of maximum ID is : %s\n",val);
    }
  }

  close(client_sock);
  return 0;
  
}
